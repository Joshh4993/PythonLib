import socketio

sio = socketio.Client()

@sio.event
def connect():
    print("Conn established")

@sio.event
def login(data):
    print('message received with', data)
    sio.emit('login', {'response': 'data'})

sio.connect('http://127.0.0.1:8000')
sio.emit('login', {"data": "Data"})
sio.wait()