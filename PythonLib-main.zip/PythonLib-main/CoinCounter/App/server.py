import uvicorn
import socketio
from datetime import datetime
import time
import services.coin_service as coins
import services.user_service as users
import services.database_service as db

# Run Server - py -m uvicorn server:app

sio = socketio.AsyncServer(async_mode='asgi')

app = socketio.ASGIApp(sio)

@sio.event
def login(sid, data):
    print(f"login: {data}, sid: {sid}")

@sio.event
def logout(sid, data):
    print(f"logout: {data}, sid: {sid}")

@sio.event
def register(sid, data):
    print(f"register: {data}, sid: {sid}")

@sio.event
def refresh(sid, data):
    print(f"refresh: {data}, sid: {sid}")

@sio.event
def verify(sid, data):
    print(f"verify: {data}, sid: {sid}")

@sio.event
def load_db(sid, data):
    print(f"load_db: {data}, sid: {sid}")

if __name__ == "__main__":
    uvicorn.run(app, host='127.0.0.1', port=8000)
