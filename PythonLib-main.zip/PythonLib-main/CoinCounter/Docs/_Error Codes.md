# ERROR_ACCS
    The max. number of accounts in the system has been reached.