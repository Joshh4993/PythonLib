from logging import PlaceHolder
from msilib.schema import Error
from platform import platform
from venv import create
import numpy as np
import json
import sys
import math

def get_settings():
    with open('settings.json') as settings_file:
        file_data = json.load(settings_file)
        default_settings = file_data['default_settings']
        return default_settings

def create_board(size_y, size_x):
    board = np.zeros((size_y, size_x), dtype=int)
    return board

def print_board(board):
    rows = []
    for row in board:
        rows.append(row)

    printable_rows = []
    for i in rows:
        row = []
        for x in i:
            if x == 0:
                row.append("⚪")
            elif x == 1:
                row.append("🔴")
            elif x == 2:
                row.append("🔵")
        printable_rows.append(row)
    print(*printable_rows, sep='\n')

def check_winning_move(board, board_size_x, board_size_y, player):
    # Horizontal Check
    for c in range(board_size_x-3):
        for r in range(board_size_y):
            if board[r][c] == player and board[r][c+1] == player and board[r][c+2] == player and board[r][c+3] == player:
                return True

    # Vertical Check
    for c in range(board_size_x):
        for r in range(board_size_y-3):
            if board[r][c] == player and board[r+1][c] == player and board[r+2][c] == player and board[r+3][c] == player:
                return True

def check_placement(board, turn, col):
    try:
        rows = []
        for row in board:
            rows.append(row)
        
        row_sel = []
        placed_marker = False
        for i in range(len(rows), 0, -1):
            while placed_marker == False:
                i -= 1
                row = rows[i]
                if row[col] == 0:
                    placed_marker = True
                    row_sel.append(i)
        
        if board[row_sel[0], col] == 0:
            return True, row_sel
        else:
            return False
    except IndexError:
        print("This is out of bounds! Please select again")
        print_board(board)
        ask_for_input(board, turn)

def ask_for_input(board, turn):
    default_settings = get_settings()
    board_size_x = default_settings['board_size_x']
    board_size_y = default_settings['board_size_y']
    if turn % 2 == 1:
        print("Player one, select the column you wish to play.")
        player_input = input("> :   ")
        input_args = player_input.split(" ")
        column =  int(input_args[0]) - 1
        response, response_row = check_placement(board, turn, col=column)
        if response == True:
            board[response_row, column] = 1
            print_board(board)
            if check_winning_move(board, board_size_x, board_size_y, 1):
                print("Player one wins!")
                sys.exit()
            else:
                turn += 1
                ask_for_input(board, turn)
    else:
        print("Player two, select the column you wish to play.")
        player_input = input("> :   ")
        input_args = player_input.split(" ")
        column =  int(input_args[0]) - 1
        response, response_row = check_placement(board, turn, col=column)
        if response == True:
            board[response_row, column] = 2
            print_board(board)
            if check_winning_move(board, board_size_x, board_size_y, 2):
                print("Player two wins!")
                sys.exit()
            else:
                turn += 1
                ask_for_input(board, turn)

def main_game():
    turn = 1
    default_settings = get_settings()
    size_x = default_settings['board_size_x']
    size_y = default_settings['board_size_y']
    board = create_board(size_y, size_x)
    print_board(board)
    ask_for_input(board, turn)

main_game()